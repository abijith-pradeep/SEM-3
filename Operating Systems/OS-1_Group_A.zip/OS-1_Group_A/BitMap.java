package os;

import java.util.Scanner;
public class BitMap
{
    int totMem;
    int []bmp_array;
    public BitMap(int totalMem){
        totMem=totalMem;
    }
    
    void create_slots(double alloc){
        alloc*=8;
        int al=(int)alloc;
        bmp_array=new int[totMem*al];
    }
    
    void fill_process(int mem,int start_add){
        mem*=8;
        for(int i =start_add;i<mem+start_add;i++){
            if(bmp_array[i]==0){
                bmp_array[i]=1;
            }
        }
    }
    
    void del_process(int mem,int start_add){
        mem*=8;
        for(int i =start_add;i<mem+start_add;i++){
            if(bmp_array[i]!=0){
                bmp_array[i]=0;
            }
        }
    }
    
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the amount of memory required: ");
        int totMem=sc.nextInt();
        BitMap btmp=new BitMap(totMem);
        System.out.println("Enter the allocation unit size: ");
        int alloc=sc.nextInt();
        btmp.create_slots(alloc);
        
        System.out.println("Enter the process p1 size: ");
        int p1=sc.nextInt();
        btmp.fill_process(p1,0);
        
        System.out.println("Deleting memory ");
        btmp.del_process(p1,0);
    }
}
