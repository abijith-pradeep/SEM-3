package os;

public class DoublyLinkedList
{
    Node head;
    class Node {

        int data;
        int start_add;
        int end_add;
        Node prev;
        Node next;

        Node(int d, int s, int e) {
            data = d;
            start_add = s;
            end_add = e;
        }
    }

    public void push(int newData, int start_add) {
        
      
        Node newNode = new Node(newData, start_add, start_add + newData);

        newNode.next = head;
        newNode.prev = null;

        if (head != null) {
            head.prev = newNode;
        }

        head = newNode;
    }

    public void InsertAfter(Node prevNode, int newData) {

        if (prevNode == null) {
            System.out.println("The given previous node cannot be NULL ");
            return;
        }
        Node newNode = new Node(newData, prevNode.next.end_add + 1, prevNode.start_add-1);
        newNode.next = prevNode.next;
        prevNode.next = newNode;
        newNode.prev = prevNode;

        if (newNode.next != null) {
            newNode.next.prev = newNode;
        }
    }

    void deleteNode(Node del) {

        if (head == null || del == null) {
            System.out.println("The head node cannot be null");
            return;
        }

        if (head == del) {
            head.data = 0;
        }
        return;
    }

    public void printlist(Node node) {

        Node last = null;
        while (node != null) {
            last = node;
            node = node.next;
        }

        while (last != null) {
            System.out.print(last.data + " " + last.start_add + " " + last.end_add + "\n");
            last = last.prev;
        }
    }

    public static void main(String[] args) {
        
        DoublyLinkedList dll = new DoublyLinkedList();

        dll.push(5, 0);
        dll.push(6, 5);

        System.out.println(dll.head.data);
        System.out.println(dll.head.next.data);
        System.out.println(dll.head.prev);
        System.out.println("Created DLL is: ");
        dll.printlist(dll.head);

    }
    
}
