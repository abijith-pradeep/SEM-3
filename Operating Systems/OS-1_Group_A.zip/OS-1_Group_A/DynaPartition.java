package os;

import os.DoublyLinkedList.*;
import java.util.Scanner;


public class DynaPartition
{
        public static void main(String args[]) {

        DoublyLinkedList TempMem = new DoublyLinkedList();

        //Input
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the space required of total memory:");

        int totMem = sc.nextInt();

        int remMem = totMem;

        int mem;

        int i = 0;

        while (i >= 0) {

            System.out.println("Enter -1 to stop the memory or type any number:");

            int stopCode = sc.nextInt();
            if (stopCode == -1) {
                return;
            }
            // First process;
            if (i == 0) {
                System.out.println("Enter the memory required for the process P" + (i + 1) + ":");
                mem = sc.nextInt();

                TempMem.push(mem, 0);
                remMem = totMem - mem;
                
                System.out.println("The available free memory is : " + remMem);
                TempMem.printlist(TempMem.head);
                i++;
            }

            System.out.println("Enter the process number that needs to be stopped ,\n"
                    + "Enter 0 if no process is to be stopped :");

            int del = sc.nextInt();

            Node start = TempMem.head;

            DoublyLinkedList Memory = TempMem;
            
            Node startMem = Memory.head;

            TempMem.head = Memory.head;

            int o = 0;

            if (del == 0 && i > 0) {

                System.out.println("Enter the memory required for the process P" + (i + 1) + ":");
                mem = sc.nextInt();

                while (TempMem != null && remMem > 0) {

                    if (o == i) {
                        System.out.println("The process could not be added");
                        break;
                    }

                    if (TempMem.head.data == 0 && TempMem.head.end_add - TempMem.head.start_add >= mem) {

                        TempMem.head.data = mem;

                        int tempEnd_add = TempMem.head.end_add;
                        
                        TempMem.head.end_add = TempMem.head.start_add + mem;

                        if (tempEnd_add - TempMem.head.start_add != mem) {
                            TempMem.InsertAfter(TempMem.head.prev, 0);
                        }

                        remMem = remMem - mem;
                        System.out.println("The available free memory is : " + remMem);
                        
                        Memory.printlist(startMem);
                        i++;
                        break;
                    }

                    if (TempMem.head.prev == null && TempMem.head.end_add + mem < totMem) {

                        TempMem.push(mem, TempMem.head.end_add + 1);

                        remMem = remMem - mem;
                        System.out.println("The available free memory is : " + remMem);

                        Memory.printlist(startMem);
                        i++;
                        break;
                    }

                    TempMem.head = TempMem.head.next;

                    o = o + 1;

                }
                
            } 

            else if (del > 0) {

                if (del > i) {
                    System.out.println("Please check the process number again.");
                    return;
                }

                int k = 1;
     
                Node tempNode = TempMem.head;

                while (TempMem != null) {

                    Node last = TempMem.head;

                    if (i - k + 1 == del){
                        
                        remMem = remMem + last.data;
                        
                        TempMem.deleteNode(last);
                        System.out.println("Available memory = " + remMem);
                      
                        TempMem.head = tempNode;
 
                        Memory.printlist(startMem);
                        break;
                    }

                    if (TempMem.head == null) {
                        System.out.println("Please check the memory required for "
                                + "process P" + (i + 1));
                        break;
                    }
                    
                    TempMem.head = TempMem.head.next;
                    k = k + 1;

                }
            }
        }
    }
}
